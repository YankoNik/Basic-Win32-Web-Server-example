﻿#pragma once
#include <afxtempl.h>

